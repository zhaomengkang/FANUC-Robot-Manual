
1. General Information

This file is a read me file of the GSDML file for PROFINET I/O function and PROFINET Safety function
of R-30iA Controller with software version 7DA7/22 or later.

2. Use condition

The GSDML file provided with this file can be used under the following conditions.

Controller :      R-30iA
System Software : 7DA7
Version :         22 or later

3. About using this file
3.1 Firmware version of CP1604/CP1616
As for the CP1604/CP1616 firmware, please use V2.5 or later.

3.2 Using I/O Controller and I/O Device at the same time
Each of I/O Controller and I/O Device need to be configured.
The GSDML provided by FANUC is used for configuration of I/O Device.
I/O Controller is to be configured as a PC Station.
I/O Controller and I/O Device must be related by "IO Device Coupling" in I/O Controller setting.
"Accept coupling with IO devices of third-party vendor" check box must be checked.

3.3 About PROFINET Safety
This GSDML file is required for using PROFINET Safety.
Please refer to the chapter "PROFINET Safety" in 
"R-30iA/R-30iA Mate controller Dual Check Safety function operator's manual" (B-83104EN).


