
1. General Information

This file is a read me file of the GSDML file for PROFINET I/O function (J930) and
PROFINET Safety function (J931) of R-30iB Controller with software version 7DC1 and 7DC2.

Note: CP1604 must be used when PROFINET Safety function is used.

2. Use condition

The GSDML file provided with this file can be used under the following conditions.

Controller :      R-30iB
System Software : 7DC1 or 7DC2
Version :         7DC1/06 or later

3. About using this file
3.1 Firmware version of CP1604/CP1616
As for the CP1604/CP1616 firmware, please use V2.5.2.2.1.

3.2 Using I/O Controller and I/O Device at the same time
Each of I/O Controller and I/O Device need to be configured.
The GSDML provided by FANUC is used for configuration of I/O Device.
I/O Controller is to be configured as a PC Station.
I/O Controller and I/O Device must be related by "IO Device Coupling" in I/O Controller setting.
"Accept coupling with IO devices of third-party vendor" check box must be checked.

3.3 About PROFINET Safety
This GSDML file is required for using PROFINET Safety.
Please refer to the chapter "PROFINET Safety" in 
"R-30iB controller Dual Check Safety function operator's manual" (B-83184EN).

4. File
- GSDML file (GSDML-V2.25-Fanuc-A05B2600J930-20120627.xml)
- Image file for icon (GSDML-01B7-0002-R2000iB165F_CP1604V25.bmp)
- Image file for icon (GSDML-01B7-0002-R2000iB165F_CP1616V25.bmp)
