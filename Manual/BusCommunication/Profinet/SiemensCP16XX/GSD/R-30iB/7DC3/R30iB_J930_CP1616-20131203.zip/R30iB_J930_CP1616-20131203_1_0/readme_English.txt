
1. General Information

This file is a read me file of the GSDML file for PROFINET I/O function (J930)
and PROFINET Safety function (J931) of R-30iB Controller with software version 7DC3.

Note: CP1604 must be used when PROFINET Safety function is used.

Note: This GSDML file can't be used for Dual Channel PROFINET(R824).

2. Use condition

The GSDML file provided with this file can be used under the following conditions.

Controller :      R-30iB
System Software : 7DC3

3. About using this file
3.1 Firmware version of CP1604/CP1616
As for the CP1604/CP1616 firmware, please use V2.6.0.3.9.

3.2 Using I/O Controller and I/O Device at the same time
Each of I/O Controller and I/O Device need to be configured.
The GSDML provided by FANUC is used for configuration of I/O Device.
I/O Controller is to be configured as a PC Station.
I/O Controller and I/O Device must be related by "IO Device Coupling" in I/O Controller setting.
"Accept coupling with IO devices of third-party vendor" check box must be checked.

3.3 About PROFINET Safety
This GSDML file is required for using PROFINET Safety.
Please refer to the chapter "PROFINET Safety" in 
"R-30iB controller Dual Check Safety function operator's manual" (B-83184EN).

3.4 I/O Device setting
When software is 7DC3 system, I/O device setting is changed.
Slot number starts from 1 and ModId of slot 1 is changed.
See enclosed "V830_PNIO_IOD_001_EN.pdf".

4 File
- GSDML file(GSDML-V2.3-Fanuc-A05B2600J930V820D6-20131203.xml) I/O Device is used on CP1616- GSDML file(GSDML-V2.3-Fanuc-A05B2600J930V820M6-20131203.xml) I/O Device and I/O Controller are used simultaneously on CP1616
- Image file for icon(GSDML-01B7-0005-R2000iB165F_CP1616V26.bmp, GSDML-01B7-0006-R2000iB165F_CP1616V26.bmp)
