
This package contains GSD file for R-30iB Plus, R-30iB Mate Plus, R-30iB Compact Plus and R-30iB Mini Plus.

1. Files for R-30iB Plus

GSD File:
GSDML-V2.33-Fanuc-A05B2600R834V910-20180517.xml

Device Icon:
GSDML-01B7-0011-R30IBPlus.bmp

2. Files for R-30iB Mate Plus

GSD File:
GSDML-V2.33-Fanuc-A05B2600R834V910M-20180411.xml

Device Icon:
GSDML-01B7-0013-R30IBMatePlus.bmp

3. Files for R-30iB Compact Plus

GSD File:
GSDML-V2.33-Fanuc-A05B2600R834V910C-20180502.xml

Device Icon:
GSDML-01B7-0015-R30IBCompactPlus.bmp

4. Files for R-30iB MiniPlus

GSD File:
GSDML-V2.33-Fanuc-A05B2600R834V910X-20201211.xml

Device Icon:
GSDML-01B7-0019-R30IBMiniPlus.bmp

